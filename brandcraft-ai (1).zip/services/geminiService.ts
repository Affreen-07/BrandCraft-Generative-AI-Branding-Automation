
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { BrandIdentity, SentimentResult, GeneratedContent } from "../types";

const API_KEY = process.env.API_KEY || '';

export const getGeminiClient = () => {
  return new GoogleGenAI({ apiKey: API_KEY });
};

export const generateBrandIdentities = async (industry: string, values: string): Promise<BrandIdentity[]> => {
  const ai = getGeminiClient();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Generate 5 creative brand names for a company in the ${industry} industry. The brand values are: ${values}.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            tagline: { type: Type.STRING },
            rational: { type: Type.STRING },
            keywords: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ["name", "tagline", "rational", "keywords"]
        }
      }
    }
  });

  try {
    return JSON.parse(response.text || '[]');
  } catch (e) {
    console.error("Failed to parse brand identities", e);
    return [];
  }
};

export const generateLogo = async (prompt: string): Promise<string | null> => {
  const ai = getGeminiClient();
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        { text: `A professional, modern, minimalist vector logo for: ${prompt}. Clean lines, high contrast, suitable for a corporate brand identity. Flat design.` }
      ]
    },
    config: {
      imageConfig: { aspectRatio: "1:1" }
    }
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  return null;
};

export const analyzeSentiment = async (feedback: string): Promise<SentimentResult | null> => {
  const ai = getGeminiClient();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze the sentiment of the following customer feedback for a brand: "${feedback}"`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          score: { type: Type.NUMBER, description: "Score from 0 to 1" },
          label: { type: Type.STRING, enum: ["Positive", "Neutral", "Negative"] },
          breakdown: {
            type: Type.OBJECT,
            properties: {
              trust: { type: Type.NUMBER },
              excitement: { type: Type.NUMBER },
              innovation: { type: Type.NUMBER }
            },
            required: ["trust", "excitement", "innovation"]
          },
          summary: { type: Type.STRING }
        },
        required: ["score", "label", "breakdown", "summary"]
      }
    }
  });

  try {
    return JSON.parse(response.text || 'null');
  } catch (e) {
    return null;
  }
};

export const generateMarketingContent = async (brandName: string, productDesc: string): Promise<GeneratedContent | null> => {
  const ai = getGeminiClient();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Create marketing content for the brand "${brandName}" launching: ${productDesc}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          headline: { type: Type.STRING },
          body: { type: Type.STRING },
          socialPosts: { type: Type.ARRAY, items: { type: Type.STRING } }
        },
        required: ["headline", "body", "socialPosts"]
      }
    }
  });

  try {
    return JSON.parse(response.text || 'null');
  } catch (e) {
    return null;
  }
};
