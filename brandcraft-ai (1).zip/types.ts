
export enum BrandFeature {
  DASHBOARD = 'DASHBOARD',
  NAME_GEN = 'NAME_GEN',
  LOGO_GEN = 'LOGO_GEN',
  CONTENT_GEN = 'CONTENT_GEN',
  SENTIMENT = 'SENTIMENT',
  ASSISTANT = 'ASSISTANT'
}

export interface BrandIdentity {
  name: string;
  tagline: string;
  rational: string;
  keywords: string[];
}

export interface SentimentResult {
  score: number;
  label: 'Positive' | 'Neutral' | 'Negative';
  breakdown: {
    trust: number;
    excitement: number;
    innovation: number;
  };
  summary: string;
}

export interface GeneratedContent {
  headline: string;
  body: string;
  socialPosts: string[];
}
