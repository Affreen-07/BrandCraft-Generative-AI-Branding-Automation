
import React, { useState, useEffect, useMemo } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import NameGenerator from './components/NameGenerator';
import LogoGenerator from './components/LogoGenerator';
import ContentGenerator from './components/ContentGenerator';
import SentimentAnalyzer from './components/SentimentAnalyzer';
import BrandingAssistant from './components/BrandingAssistant';
import LoginPage from './components/LoginPage';
import OpeningPage from './components/OpeningPage';
import { BrandFeature } from './types';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<BrandFeature>(BrandFeature.DASHBOARD);
  const [isAssistantOpen, setIsAssistantOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState('');
  const [showOpening, setShowOpening] = useState(true);

  // Persist session locally
  useEffect(() => {
    const savedUser = localStorage.getItem('brandcraft_user');
    if (savedUser) {
      setUsername(savedUser);
      setIsLoggedIn(true);
    }
  }, []);

  const handleLogin = (user: string) => {
    setUsername(user);
    setIsLoggedIn(true);
    localStorage.setItem('brandcraft_user', user);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUsername('');
    localStorage.removeItem('brandcraft_user');
    setActiveTab(BrandFeature.DASHBOARD);
  };

  const themeColors = useMemo(() => {
    switch (activeTab) {
      case BrandFeature.NAME_GEN:
        return { 
          blob1: 'bg-sky-300/60', 
          blob2: 'bg-blue-200/50', 
          blob3: 'bg-indigo-200/40', 
          accent: 'text-sky-300/50',
          base: 'bg-[#f0f7ff]' 
        };
      case BrandFeature.LOGO_GEN:
        return { 
          blob1: 'bg-amber-300/60', 
          blob2: 'bg-orange-200/50', 
          blob3: 'bg-yellow-200/40', 
          accent: 'text-amber-300/50',
          base: 'bg-[#fffcf0]' 
        };
      case BrandFeature.CONTENT_GEN:
        return { 
          blob1: 'bg-emerald-300/60', 
          blob2: 'bg-teal-200/50', 
          blob3: 'bg-green-200/40', 
          accent: 'text-emerald-300/50',
          base: 'bg-[#f0fff7]' 
        };
      case BrandFeature.SENTIMENT:
        return { 
          blob1: 'bg-purple-300/60', 
          blob2: 'bg-violet-200/50', 
          blob3: 'bg-fuchsia-200/40', 
          accent: 'text-purple-300/50',
          base: 'bg-[#faf0ff]' 
        };
      default:
        return { 
          blob1: 'bg-rose-300/60', 
          blob2: 'bg-amber-200/50', 
          blob3: 'bg-pink-200/40', 
          accent: 'text-rose-300/50',
          base: 'bg-[#fff5f5]' 
        };
    }
  }, [activeTab]);

  const renderContent = () => {
    switch (activeTab) {
      case BrandFeature.DASHBOARD:
        return <Dashboard onNavigate={(feature) => setActiveTab(feature)} />;
      case BrandFeature.NAME_GEN:
        return <NameGenerator />;
      case BrandFeature.LOGO_GEN:
        return <LogoGenerator />;
      case BrandFeature.CONTENT_GEN:
        return <ContentGenerator />;
      case BrandFeature.SENTIMENT:
        return <SentimentAnalyzer />;
      default:
        return <Dashboard onNavigate={(feature) => setActiveTab(feature)} />;
    }
  };

  if (showOpening) {
    return <OpeningPage onFinish={() => setShowOpening(false)} />;
  }

  if (!isLoggedIn) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <div className={`flex min-h-screen relative overflow-hidden transition-colors duration-1000 ${themeColors.base}`}>
      <div className="fixed inset-0 pointer-events-none select-none overflow-hidden z-0">
        <div className={`absolute top-[-10%] left-[5%] w-[55vw] h-[55vw] rounded-full blur-[160px] animate-float transition-all duration-1000 ${themeColors.blob1}`}></div>
        <div className={`absolute bottom-[-15%] right-[-5%] w-[50vw] h-[50vw] rounded-full blur-[140px] animate-float-delayed transition-all duration-1000 ${themeColors.blob2}`}></div>
        <div className={`absolute top-[25%] right-[10%] w-[35vw] h-[35vw] rounded-full blur-[120px] animate-float-slow transition-all duration-1000 ${themeColors.blob3}`}></div>
      </div>

      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} onLogout={handleLogout} username={username} />
      
      <main className="flex-1 overflow-y-auto h-screen relative z-10">
        <header className="sticky top-0 z-20 glass border-b border-stone-200/50 px-8 py-5 flex justify-between items-center transition-all bg-white/40">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-indigo-950 rounded-xl flex items-center justify-center p-1.5 shadow-sm">
              <svg viewBox="0 0 100 100" className="w-full h-full">
                <path d="M 50 10 L 90 50 L 50 90 L 10 50 Z" fill="none" stroke="#FFFFFF" strokeWidth="1" opacity="0.3" />
                <path d="M 32 30 V 70 H 45 C 55 70 58 60 58 52 C 58 46 54 42 48 42 C 54 42 56 36 56 32 C 56 26 52 22 42 22 H 32" fill="none" stroke="#FFFFFF" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M 72 32 C 68 22 55 20 48 24 C 40 28 38 45 42 58 C 45 68 55 78 68 76 C 75 75 78 68 78 60" fill="none" stroke="#FFFFFF" strokeWidth="7" strokeLinecap="round" opacity="0.85" />
              </svg>
            </div>
            <div>
              <h1 
                className="text-2xl font-normal text-stone-800 tracking-tight"
                style={{ fontFamily: "'Times New Roman', Times, serif" }}
              >
                Brand<span className="text-rose-500 italic">Craft</span>
              </h1>
              <div className="flex items-center gap-2">
                <p className="text-[10px] text-stone-500 uppercase tracking-[0.2em] font-bold">The AI Powered Branding Suite</p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-6">
            <button 
              onClick={() => setIsAssistantOpen(!isAssistantOpen)}
              className="bg-white/80 backdrop-blur-md hover:bg-white text-rose-700 px-6 py-3 rounded-2xl text-xs font-black transition-all flex items-center gap-3 shadow-sm border border-rose-200"
            >
              <div className="w-5 h-5 bg-indigo-950 rounded-md flex items-center justify-center p-0.5">
                <svg viewBox="0 0 100 100" className="w-full h-full">
                  <path d="M 32 30 V 70 H 45 C 55 70 58 60 58 52 C 58 46 54 42 48 42 C 54 42 56 36 56 32 C 56 26 52 22 42 22 H 32" fill="none" stroke="#FFFFFF" strokeWidth="12" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M 72 32 C 68 22 55 20 48 24 C 40 28 38 45 42 58 C 45 68 55 78 68 76 C 75 75 78 68 78 60" fill="none" stroke="#FFFFFF" strokeWidth="10" strokeLinecap="round" opacity="0.85" />
                </svg>
              </div>
              Assistant
            </button>
            <div className="flex items-center gap-3 pl-6 border-l border-stone-200/50">
              <div className="text-right hidden sm:block">
                <p className="text-xs font-black text-stone-800">{username}</p>
                <div className="flex items-center gap-1.5 justify-end">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]"></div>
                  <p className="text-[9px] text-stone-500 font-bold uppercase tracking-widest">Online</p>
                </div>
              </div>
              <div className="w-11 h-11 rounded-2xl bg-white flex items-center justify-center border border-stone-200 text-rose-400 shadow-sm overflow-hidden p-2">
                <svg viewBox="0 0 100 100" className="w-full h-full opacity-40">
                  <path d="M 32 30 V 70 H 45 C 55 70 58 60 58 52 C 58 46 54 42 48 42 C 54 42 56 36 56 32 C 56 26 52 22 42 22 H 32" fill="none" stroke="currentColor" strokeWidth="12" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M 72 32 C 68 22 55 20 48 24 C 40 28 38 45 42 58 C 45 68 55 78 68 76 C 75 75 78 68 78 60" fill="none" stroke="currentColor" strokeWidth="10" strokeLinecap="round" opacity="0.85" />
                </svg>
              </div>
            </div>
          </div>
        </header>

        <div className="p-8 max-w-7xl mx-auto relative z-10">
          {renderContent()}
        </div>

        {isAssistantOpen && (
          <div className="fixed bottom-6 right-6 z-50 w-[420px] h-[700px] shadow-[0_32px_64px_-12px_rgba(0,0,0,0.15)] rounded-[3rem] overflow-hidden border border-stone-200 bg-white/95 backdrop-blur-xl flex flex-col transition-all transform animate-in slide-in-from-bottom-8">
            <div className="bg-rose-100/40 p-7 flex justify-between items-center text-rose-900 border-b border-rose-200/50">
              <div className="flex items-center gap-4">
                <div className="w-11 h-11 rounded-2xl bg-indigo-950 flex items-center justify-center p-2 shadow-sm border border-rose-100">
                  <svg viewBox="0 0 100 100" className="w-full h-full">
                    <path d="M 32 30 V 70 H 45 C 55 70 58 60 58 52 C 58 46 54 42 48 42 C 54 42 56 36 56 32 C 56 26 52 22 42 22 H 32" fill="none" stroke="#FFFFFF" strokeWidth="12" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M 72 32 C 68 22 55 20 48 24 C 40 28 38 45 42 58 C 45 68 55 78 68 76 C 75 75 78 68 78 60" fill="none" stroke="#FFFFFF" strokeWidth="10" strokeLinecap="round" opacity="0.85" />
                  </svg>
                </div>
                <div>
                  <span className="font-black text-sm block tracking-tight">BrandCraft Strategist</span>
                  <div className="flex items-center gap-1.5 opacity-60">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
                    <span className="text-[9px] uppercase font-bold tracking-[0.15em]">System Active</span>
                  </div>
                </div>
              </div>
              <button onClick={() => setIsAssistantOpen(false)} className="w-9 h-9 rounded-full hover:bg-rose-100 transition-colors flex items-center justify-center text-rose-400">
                <i className="fas fa-times"></i>
              </button>
            </div>
            <BrandingAssistant />
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
