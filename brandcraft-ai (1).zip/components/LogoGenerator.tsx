
import React, { useState } from 'react';
import { generateLogo } from '../services/geminiService';

const LogoGenerator: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [generatedLogo, setGeneratedLogo] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    if (!prompt) return;
    setLoading(true);
    try {
      const url = await generateLogo(prompt);
      setGeneratedLogo(url);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      <div className="bg-white rounded-[2.5rem] p-12 border border-stone-100 shadow-sm">
        <div className="flex items-center gap-4 mb-10">
          <div className="w-14 h-14 rounded-2xl bg-amber-50 text-amber-400 flex items-center justify-center text-2xl border border-amber-100">
            <i className="fas fa-paint-brush"></i>
          </div>
          <div>
            <h2 className="text-3xl font-black text-stone-800">Logo Studio</h2>
            <p className="text-stone-400 font-medium text-sm">Visualizing professional brand marks using Gemini Flash Image.</p>
          </div>
        </div>

        <div className="space-y-6">
          <label className="block text-[11px] font-black uppercase tracking-widest text-stone-400 mb-1 ml-1">Visual Concept Prompt</label>
          <textarea
            className="w-full px-6 py-5 rounded-[2rem] bg-stone-50 border border-stone-100 focus:ring-4 focus:ring-amber-50 focus:bg-white focus:outline-none transition-all font-medium text-stone-800 h-40 resize-none"
            placeholder="Describe your vision... e.g. A minimalist hawk with spread wings, geometric lines, amber tones."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
          />
        </div>
        
        <button
          onClick={handleGenerate}
          disabled={loading || !prompt}
          className="mt-10 w-full px-12 py-5 bg-amber-100 text-amber-700 font-black rounded-2xl hover:bg-amber-200 disabled:opacity-50 transition-all shadow-sm border border-amber-200 flex items-center justify-center gap-3"
        >
          {loading ? <i className="fas fa-magic fa-spin"></i> : <i className="fas fa-magic"></i>}
          Visualize Brand Concept
        </button>
      </div>

      {generatedLogo && (
        <div className="bg-white rounded-[2.5rem] p-12 border border-stone-100 shadow-sm flex flex-col items-center">
          <h3 className="text-xl font-black mb-10 text-stone-800">Generative Concept Result</h3>
          <div className="relative group rounded-[2rem] overflow-hidden shadow-2xl max-w-lg w-full aspect-square border-8 border-stone-50">
            <img src={generatedLogo} alt="AI Generated Logo" className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-stone-900/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-6">
              <button className="bg-white text-stone-900 px-6 py-3 rounded-2xl font-black hover:bg-stone-50 shadow-lg transform translate-y-4 group-hover:translate-y-0 transition-all duration-300">
                <i className="fas fa-download mr-3"></i>
                Export SVG
              </button>
            </div>
          </div>
          <p className="mt-10 text-stone-400 text-sm italic text-center max-w-md font-medium">
            "Every mark is uniquely architected. Use this high-fidelity concept as a foundation for final refinement."
          </p>
        </div>
      )}
    </div>
  );
};

export default LogoGenerator;
