
import React from 'react';
import { BrandFeature } from '../types';

interface DashboardProps {
  onNavigate: (feature: BrandFeature) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  const cards = [
    {
      id: BrandFeature.NAME_GEN,
      title: 'Brand Naming',
      desc: 'Architect unique identities using semantic AI to find the perfect name.',
      icon: 'fa-signature',
      color: 'bg-rose-50 text-rose-500 border-rose-100',
      tag: 'Creative'
    },
    {
      id: BrandFeature.LOGO_GEN,
      title: 'Logo Studio',
      desc: 'Generate professional minimalist vector concepts in seconds.',
      icon: 'fa-paint-brush',
      color: 'bg-sky-50 text-sky-500 border-sky-100',
      tag: 'Visual'
    },
    {
      id: BrandFeature.CONTENT_GEN,
      title: 'Content Lab',
      desc: 'Automate high-converting copy and social media strategies.',
      icon: 'fa-file-alt',
      color: 'bg-amber-50 text-amber-500 border-amber-100',
      tag: 'Marketing'
    },
    {
      id: BrandFeature.SENTIMENT,
      title: 'Sentiment AI',
      desc: 'Deep analysis of customer perception and emotional resonance.',
      icon: 'fa-chart-line',
      color: 'bg-purple-50 text-purple-500 border-purple-100',
      tag: 'Intelligence'
    }
  ];

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-6 duration-700">
      {/* Pastel Hero Section */}
      <div className="relative overflow-hidden rounded-[3rem] bg-gradient-to-br from-rose-50 via-white to-sky-50 p-16 border border-white shadow-xl shadow-rose-100/20">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-block px-4 py-1.5 rounded-full bg-white text-[10px] font-black uppercase tracking-[0.2em] text-rose-400 mb-8 border border-rose-50 shadow-sm">
            AI-Driven Identity
          </div>
          <h2 className="text-6xl font-black mb-8 leading-[1.1] tracking-tight text-stone-800">
            Crafting the <br /> 
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-rose-400 to-amber-400">next-gen icons.</span>
          </h2>
          <p className="text-stone-500 text-xl mb-12 leading-relaxed max-w-lg font-medium">
            Streamline your branding workflow. From generative naming to deep sentiment analysis, powered by the core of Gemini.
          </p>
          <div className="flex gap-6">
            <button 
              onClick={() => onNavigate(BrandFeature.NAME_GEN)}
              className="bg-stone-800 hover:bg-stone-900 text-white px-10 py-5 rounded-[1.5rem] font-black transition-all shadow-xl shadow-stone-200 hover:-translate-y-1 active:scale-95"
            >
              Start Creating
            </button>
            <button className="bg-white hover:bg-stone-50 text-stone-800 border border-stone-200 px-10 py-5 rounded-[1.5rem] font-black transition-all shadow-sm">
              Learn More
            </button>
          </div>
        </div>
        
        {/* Abstract Background Doodles */}
        <div className="absolute top-0 right-0 w-1/2 h-full opacity-30 pointer-events-none select-none">
          <div className="absolute top-1/2 right-0 -translate-y-1/2 translate-x-1/4 w-[500px] h-[500px] bg-rose-200/20 rounded-full blur-[100px]"></div>
          <div className="absolute top-1/4 right-1/4 w-[300px] h-[300px] bg-sky-200/20 rounded-full blur-[80px]"></div>
          <div className="absolute top-1/2 right-10 -translate-y-1/2 transform rotate-12 w-[350px] h-[350px] opacity-10">
            <svg viewBox="0 0 100 100" className="w-full h-full text-rose-400">
               <path d="M 32 30 V 70 H 45 C 55 70 58 60 58 52 C 58 46 54 42 48 42 C 54 42 56 36 56 32 C 56 26 52 22 42 22 H 32" fill="none" stroke="currentColor" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" />
               <path d="M 72 32 C 68 22 55 20 48 24 C 40 28 38 45 42 58 C 45 68 55 78 68 76 C 75 75 78 68 78 60" fill="none" stroke="currentColor" strokeWidth="7" strokeLinecap="round" opacity="0.85" />
            </svg>
          </div>
        </div>
      </div>

      {/* Feature Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
        {cards.map((card) => (
          <div 
            key={card.id}
            onClick={() => onNavigate(card.id)}
            className="group cursor-pointer bg-white rounded-[2.5rem] p-10 border border-stone-100 shadow-sm hover:shadow-2xl hover:-translate-y-3 transition-all duration-500"
          >
            <div className={`${card.color} w-20 h-20 rounded-3xl flex items-center justify-center mb-10 shadow-sm border transform group-hover:scale-110 group-hover:rotate-6 transition-all duration-500`}>
              <i className={`fas ${card.icon} text-3xl`}></i>
            </div>
            <div className="inline-block px-4 py-1 rounded-full bg-stone-50 text-[10px] font-black uppercase tracking-[0.15em] text-stone-400 mb-6">
              {card.tag}
            </div>
            <h3 className="text-2xl font-black mb-4 text-stone-800 tracking-tight group-hover:text-rose-400 transition-colors">{card.title}</h3>
            <p className="text-stone-500 text-sm leading-relaxed mb-10 font-medium">{card.desc}</p>
            <div className="flex items-center text-stone-400 font-black text-[10px] uppercase tracking-[0.25em] pt-6 border-t border-stone-50 group-hover:text-stone-800 transition-colors">
              Access Tool <i className="fas fa-arrow-right ml-4 group-hover:translate-x-3 transition-transform"></i>
            </div>
          </div>
        ))}
      </div>

      {/* Secondary Pastel CTA */}
      <div className="bg-[#fff9f9] rounded-[3rem] p-12 border border-rose-50 flex flex-col lg:flex-row items-center justify-between gap-12 shadow-sm">
        <div className="flex gap-10 items-center">
          <div className="w-24 h-24 rounded-[2rem] bg-white flex items-center justify-center text-rose-300 text-4xl shadow-sm border border-rose-50">
            <i className="fas fa-rocket"></i>
          </div>
          <div>
            <h4 className="text-3xl font-black text-stone-800 mb-2">Ready to scale?</h4>
            <p className="text-stone-500 text-lg font-medium">Connect your store and start monitoring global sentiment in real-time.</p>
          </div>
        </div>
        <button className="bg-white text-stone-800 px-10 py-5 rounded-[1.5rem] font-black border border-stone-100 hover:bg-stone-50 transition-all shadow-sm whitespace-nowrap min-w-[200px]">
          View Integrations
        </button>
      </div>
    </div>
  );
};

export default Dashboard;
