
import React, { useState, useEffect } from 'react';

interface OpeningPageProps {
  onFinish: () => void;
}

const OpeningPage: React.FC<OpeningPageProps> = ({ onFinish }) => {
  const [showContent, setShowContent] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setShowContent(true), 100);
    return () => clearTimeout(timer);
  }, []);

  // Background doodles adjusted for lavender/purple theme
  const doodles = [
    { icon: 'fa-signature', pos: 'top-10 left-[10%]', anim: 'animate-float' },
    { icon: 'fa-paint-brush', pos: 'top-20 right-[15%]', anim: 'animate-float-delayed' },
    { icon: 'fa-chart-line', pos: 'bottom-20 left-[12%]', anim: 'animate-float-slow' },
    { icon: 'fa-lightbulb', pos: 'bottom-40 right-[10%]', anim: 'animate-float' },
    { icon: 'fa-wand-magic-sparkles', pos: 'top-[40%] left-[5%]', anim: 'animate-float-delayed' },
    { icon: 'fa-bullhorn', pos: 'bottom-[10%] right-[30%]', anim: 'animate-float-slow' },
    { icon: 'fa-gem', pos: 'top-[60%] right-[5%]', anim: 'animate-float' },
  ];

  return (
    <div className="fixed inset-0 bg-[#E6E6FA] bg-gradient-to-br from-[#E6E6FA] via-[#D8BFD8] to-[#9370DB] flex flex-col items-center justify-center z-[100] overflow-hidden">
      {/* Movable Theme Background Doodles */}
      <div className="absolute inset-0 pointer-events-none select-none overflow-hidden">
        {doodles.map((doodle, idx) => (
          <div 
            key={idx} 
            className={`absolute ${doodle.pos} ${doodle.anim} text-white/40 text-6xl opacity-30`}
          >
            <i className={`fas ${doodle.icon}`}></i>
          </div>
        ))}
        {/* Subtle geometric shapes - Purple/Lavender theme */}
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-white/20 blur-3xl"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full bg-purple-200/20 blur-3xl"></div>
      </div>

      <div className={`transition-all duration-1000 transform ${showContent ? 'opacity-100 scale-100' : 'opacity-0 scale-95'} flex flex-col items-center relative z-10 px-6 text-center`}>
        
        {/* Interactive Geometric BC Prism Logo */}
        <button 
          onClick={onFinish}
          className="relative w-80 h-80 mb-12 flex items-center justify-center group outline-none focus:outline-none cursor-pointer"
        >
          {/* Animated Glow / Pulse Ring */}
          <div className="absolute inset-0 bg-indigo-900/30 rounded-full blur-[80px] group-hover:bg-indigo-900/40 transition-all duration-700 animate-pulse"></div>
          
          {/* Main Logo Container - Darker Lavender Background (Indigo-Purple) */}
          <div className="relative w-64 h-64 bg-indigo-950/70 backdrop-blur-2xl rounded-3xl flex items-center justify-center shadow-[0_20px_50px_rgba(0,0,0,0.3)] border-2 border-white/20 group-hover:scale-105 group-hover:rotate-2 transition-all duration-700">
            <svg viewBox="0 0 100 100" className="w-48 h-48 drop-shadow-[0_0_15px_rgba(255,255,255,0.4)]">
              {/* Geometric Frame / Diamond Shape */}
              <path 
                d="M 50 10 L 90 50 L 50 90 L 10 50 Z" 
                fill="none" 
                stroke="#FFFFFF" 
                strokeWidth="0.5" 
                strokeDasharray="2 2"
                opacity="0.3"
              />

              {/* Interlocking BC Monogram - Minimalist High Fashion Style */}
              <g transform="translate(0, 0)">
                {/* Stylized 'B' with a Fountain Pen Nib detail */}
                <path 
                  d="M 32 30 V 70 H 45 C 55 70 58 60 58 52 C 58 46 54 42 48 42 C 54 42 56 36 56 32 C 56 26 52 22 42 22 H 32" 
                  fill="none" 
                  stroke="#FFFFFF" 
                  strokeWidth="6" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                  className="animate-[draw_3s_ease-out_forwards]"
                  style={{ strokeDasharray: 300, strokeDashoffset: 300 }}
                />
                
                {/* Stylized 'C' flowing behind 'B' */}
                <path 
                  d="M 72 32 C 68 22 55 20 48 24 C 40 28 38 45 42 58 C 45 68 55 78 68 76 C 75 75 78 68 78 60" 
                  fill="none" 
                  stroke="#FFFFFF" 
                  strokeWidth="5" 
                  strokeLinecap="round" 
                  opacity="0.85"
                  className="animate-[draw_3.5s_ease-out_forwards]"
                  style={{ strokeDasharray: 300, strokeDashoffset: 300, animationDelay: '0.5s' }}
                />
                
                {/* Central Point / "AI Core" Sparkle */}
                <circle 
                  cx="48" cy="42" r="2.5" 
                  fill="#FFFFFF" 
                  className="animate-pulse shadow-white shadow-2xl"
                />
              </g>

              {/* Orbital Lines indicating "Craft/Automation" */}
              <circle 
                cx="50" cy="50" r="42" 
                fill="none" 
                stroke="#FFFFFF" 
                strokeWidth="1.5" 
                strokeLinecap="round" 
                style={{ strokeDasharray: '10, 154' }}
                className="animate-[spin_8s_linear_infinite]"
              />
              <circle 
                cx="50" cy="50" r="38" 
                fill="none" 
                stroke="#FFFFFF" 
                strokeWidth="0.75" 
                opacity="0.2"
              />
            </svg>
          </div>
        </button>

        {/* Branding Typography */}
        <div className="space-y-4">
          <h1 
            className="text-6xl font-normal tracking-tight text-stone-900" 
            style={{ fontFamily: "'Times New Roman', Times, serif" }}
          >
            Brand<span className="text-white drop-shadow-md font-italic italic">Craft</span>
          </h1>
          <div className="flex flex-col items-center">
            <p className="text-white/80 font-black uppercase tracking-[0.5em] text-[10px] drop-shadow-sm">
              Generative Identity Engine v4.2
            </p>
            <div className="mt-8 h-[1px] w-40 bg-gradient-to-r from-transparent via-white/50 to-transparent"></div>
          </div>
        </div>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes draw {
          to { stroke-dashoffset: 0; }
        }
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}} />
    </div>
  );
};

export default OpeningPage;
