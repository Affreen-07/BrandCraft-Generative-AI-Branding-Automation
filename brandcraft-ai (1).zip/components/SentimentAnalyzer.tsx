
import React, { useState } from 'react';
import { analyzeSentiment } from '../services/geminiService';
import { SentimentResult } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const SentimentAnalyzer: React.FC = () => {
  const [feedback, setFeedback] = useState('');
  const [result, setResult] = useState<SentimentResult | null>(null);
  const [loading, setLoading] = useState(false);

  const handleAnalyze = async () => {
    if (!feedback) return;
    setLoading(true);
    try {
      const data = await analyzeSentiment(feedback);
      setResult(data);
    } finally {
      setLoading(false);
    }
  };

  const chartData = result ? [
    { name: 'Trust', value: result.breakdown.trust * 100 },
    { name: 'Excitement', value: result.breakdown.excitement * 100 },
    { name: 'Innovation', value: result.breakdown.innovation * 100 },
  ] : [];

  const COLORS = ['#d8b4fe', '#c084fc', '#a855f7']; // Purple pastels

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      <div className="bg-white rounded-[2.5rem] p-12 border border-stone-100 shadow-sm">
        <div className="flex items-center gap-4 mb-10">
          <div className="w-14 h-14 rounded-2xl bg-purple-50 text-purple-400 flex items-center justify-center text-2xl border border-purple-100">
            <i className="fas fa-chart-line"></i>
          </div>
          <div>
            <h2 className="text-3xl font-black text-stone-800">Sentiment Intelligence</h2>
            <p className="text-stone-400 font-medium text-sm">Decode the emotional resonance of your customer base.</p>
          </div>
        </div>

        <div className="space-y-6">
          <label className="block text-[11px] font-black uppercase tracking-widest text-stone-400 mb-1 ml-1">Feedback Sample</label>
          <textarea
            className="w-full px-6 py-5 rounded-[2rem] bg-stone-50 border border-stone-100 focus:ring-4 focus:ring-purple-50 focus:bg-white focus:outline-none transition-all font-medium text-stone-800 h-44 resize-none"
            placeholder="Paste reviews, social mentions, or survey responses here..."
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
          />
        </div>
        
        <button
          onClick={handleAnalyze}
          disabled={loading || !feedback}
          className="mt-10 w-full px-12 py-5 bg-purple-100 text-purple-700 font-black rounded-2xl hover:bg-purple-200 disabled:opacity-50 transition-all shadow-sm border border-purple-200 flex items-center justify-center gap-3"
        >
          {loading ? <i className="fas fa-microscope fa-spin"></i> : <i className="fas fa-microscope"></i>}
          Analyze Emotional Data
        </button>
      </div>

      {result && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          <div className="lg:col-span-2 bg-white rounded-[2.5rem] p-12 border border-stone-100 shadow-sm">
            <h3 className="text-xl font-black mb-10 text-stone-800">Perception Metrics</h3>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f5f5f5" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#a8a29e', fontSize: 11, fontWeight: 700}} />
                  <YAxis domain={[0, 100]} axisLine={false} tickLine={false} tick={{fill: '#a8a29e', fontSize: 11, fontWeight: 700}} />
                  <Tooltip 
                    cursor={{fill: '#f5f5f5', radius: 12}}
                    contentStyle={{borderRadius: '24px', border: 'none', boxShadow: '0 25px 50px -12px rgb(0 0 0 / 0.1)', padding: '16px'}}
                  />
                  <Bar dataKey="value" radius={[12, 12, 0, 0]} barSize={60}>
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-white rounded-[2.5rem] p-12 border border-stone-100 shadow-sm flex flex-col items-center justify-center text-center">
            <div className="w-20 h-20 rounded-full bg-stone-50 flex items-center justify-center text-3xl mb-8 border border-stone-100">
              {result.label === 'Positive' ? '✨' : result.label === 'Negative' ? '⚠️' : '⚖️'}
            </div>
            <p className="text-stone-400 font-black uppercase text-[10px] tracking-widest mb-3">Overall Pulse</p>
            <div className={`text-5xl font-black mb-6 tracking-tight ${
              result.label === 'Positive' ? 'text-emerald-400' : result.label === 'Negative' ? 'text-rose-400' : 'text-stone-400'
            }`}>
              {result.label}
            </div>
            <div className="w-full h-2.5 bg-stone-50 rounded-full overflow-hidden flex mb-8 border border-stone-100">
              <div className="bg-purple-400 h-full transition-all duration-1000" style={{ width: `${result.score * 100}%` }}></div>
            </div>
            <p className="text-stone-500 text-sm leading-relaxed font-medium italic">
              "{result.summary}"
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default SentimentAnalyzer;
