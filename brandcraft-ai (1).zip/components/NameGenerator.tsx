
import React, { useState } from 'react';
import { generateBrandIdentities } from '../services/geminiService';
import { BrandIdentity } from '../types';

const NameGenerator: React.FC = () => {
  const [industry, setIndustry] = useState('');
  const [values, setValues] = useState('');
  const [results, setResults] = useState<BrandIdentity[]>([]);
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    if (!industry || !values) return;
    setLoading(true);
    try {
      const data = await generateBrandIdentities(industry, values);
      setResults(data);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      <div className="bg-white rounded-[2.5rem] p-12 border border-stone-100 shadow-sm">
        <div className="flex items-center gap-4 mb-10">
          <div className="w-14 h-14 rounded-2xl bg-sky-50 text-sky-400 flex items-center justify-center text-2xl border border-sky-100">
            <i className="fas fa-signature"></i>
          </div>
          <div>
            <h2 className="text-3xl font-black text-stone-800">Identity Architect</h2>
            <p className="text-stone-400 font-medium text-sm">Generate semantic brand identities with deep reasoning.</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          <div>
            <label className="block text-[11px] font-black uppercase tracking-widest text-stone-400 mb-3 ml-1">Industry Sector</label>
            <input
              type="text"
              className="w-full px-6 py-5 rounded-2xl bg-stone-50 border border-stone-100 focus:ring-4 focus:ring-sky-50 focus:bg-white focus:outline-none transition-all font-medium text-stone-800"
              placeholder="e.g. Sustainable Fashion"
              value={industry}
              onChange={(e) => setIndustry(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-[11px] font-black uppercase tracking-widest text-stone-400 mb-3 ml-1">Brand Ethos</label>
            <input
              type="text"
              className="w-full px-6 py-5 rounded-2xl bg-stone-50 border border-stone-100 focus:ring-4 focus:ring-sky-50 focus:bg-white focus:outline-none transition-all font-medium text-stone-800"
              placeholder="e.g. Modern, Minimal, Playful"
              value={values}
              onChange={(e) => setValues(e.target.value)}
            />
          </div>
        </div>
        
        <button
          onClick={handleGenerate}
          disabled={loading || !industry}
          className="mt-12 w-full lg:w-auto px-12 py-5 bg-sky-100 text-sky-700 font-black rounded-2xl hover:bg-sky-200 disabled:opacity-50 transition-all shadow-sm flex items-center justify-center gap-3 border border-sky-200"
        >
          {loading ? <i className="fas fa-circle-notch fa-spin"></i> : <i className="fas fa-wand-magic-sparkles"></i>}
          Draft Brand Identities
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
        {results.map((brand, idx) => (
          <div key={idx} className="bg-white rounded-[2rem] p-8 border border-stone-100 shadow-sm hover:shadow-xl transition-all group flex flex-col h-full">
            <div className="flex justify-between items-start mb-6">
              <h3 className="text-2xl font-black text-stone-800 tracking-tight group-hover:text-sky-500 transition-colors">{brand.name}</h3>
              <button className="w-10 h-10 rounded-full hover:bg-rose-50 text-stone-300 hover:text-rose-400 transition-all flex items-center justify-center">
                <i className="far fa-heart"></i>
              </button>
            </div>
            <p className="text-sm font-bold text-sky-600 italic mb-6">"{brand.tagline}"</p>
            <p className="text-stone-500 text-sm mb-8 line-clamp-4 leading-relaxed font-medium flex-grow">{brand.rational}</p>
            
            <div className="flex flex-wrap gap-2 pt-6 border-t border-stone-50">
              {brand.keywords.map((kw, kidx) => (
                <span key={kidx} className="px-3 py-1.5 bg-stone-50 text-stone-500 rounded-lg text-[10px] uppercase font-black tracking-widest border border-stone-100">
                  {kw}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default NameGenerator;
