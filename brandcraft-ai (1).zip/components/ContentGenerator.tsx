
import React, { useState } from 'react';
import { generateMarketingContent } from '../services/geminiService';
import { GeneratedContent } from '../types';

const ContentGenerator: React.FC = () => {
  const [brandName, setBrandName] = useState('');
  const [productDesc, setProductDesc] = useState('');
  const [result, setResult] = useState<GeneratedContent | null>(null);
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    if (!brandName || !productDesc) return;
    setLoading(true);
    try {
      const data = await generateMarketingContent(brandName, productDesc);
      setResult(data);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      <div className="bg-white rounded-[2.5rem] p-12 border border-stone-100 shadow-sm">
        <div className="flex items-center gap-4 mb-10">
          <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-400 flex items-center justify-center text-2xl border border-emerald-100">
            <i className="fas fa-file-alt"></i>
          </div>
          <div>
            <h2 className="text-3xl font-black text-stone-800">Content Lab</h2>
            <p className="text-stone-400 font-medium text-sm">Automate campaign drafts and social presence instantly.</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 mb-10">
          <div>
            <label className="block text-[11px] font-black uppercase tracking-widest text-stone-400 mb-3 ml-1">Brand Anchor</label>
            <input
              type="text"
              className="w-full px-6 py-5 rounded-2xl bg-stone-50 border border-stone-100 focus:ring-4 focus:ring-emerald-500/10 focus:bg-white focus:outline-none transition-all font-medium text-stone-800"
              placeholder="e.g. Lumina Bloom"
              value={brandName}
              onChange={(e) => setBrandName(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-[11px] font-black uppercase tracking-widest text-stone-400 mb-3 ml-1">Campaign Narrative</label>
            <input
              type="text"
              className="w-full px-6 py-5 rounded-2xl bg-stone-50 border border-stone-100 focus:ring-4 focus:ring-emerald-500/10 focus:bg-white focus:outline-none transition-all font-medium text-stone-800"
              placeholder="What are we promoting?"
              value={productDesc}
              onChange={(e) => setProductDesc(e.target.value)}
            />
          </div>
        </div>
        
        <button
          onClick={handleGenerate}
          disabled={loading || !brandName}
          className="w-full px-12 py-5 bg-emerald-100 text-emerald-700 font-black rounded-2xl hover:bg-emerald-200 disabled:opacity-50 transition-all shadow-sm border border-emerald-200 flex items-center justify-center gap-3"
        >
          {loading ? <i className="fas fa-pen-nib fa-spin"></i> : <i className="fas fa-pen-nib"></i>}
          Draft Campaign Materials
        </button>
      </div>

      {result && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          <div className="bg-white rounded-[2.5rem] p-12 border border-stone-100 shadow-sm space-y-10">
            <div>
              <h3 className="text-[10px] font-black text-stone-400 uppercase tracking-widest mb-4">Core Headline</h3>
              <p className="text-3xl font-black text-stone-800 leading-tight">{result.headline}</p>
            </div>
            <div>
              <h3 className="text-[10px] font-black text-stone-400 uppercase tracking-widest mb-4">Draft Body Copy</h3>
              <p className="text-stone-500 leading-relaxed font-medium text-lg">{result.body}</p>
            </div>
            <button className="text-emerald-500 font-black text-xs uppercase tracking-widest hover:text-emerald-700 flex items-center gap-3">
              <i className="fas fa-copy"></i> Copy Narrative
            </button>
          </div>

          <div className="space-y-8">
            <h3 className="text-xl font-black text-stone-800 px-2">Social Pulse Pack</h3>
            {result.socialPosts.map((post, idx) => (
              <div key={idx} className="bg-emerald-50/50 rounded-[2rem] p-8 border border-emerald-100 relative group hover:bg-emerald-50 transition-colors">
                <div className="flex gap-6">
                  <div className="w-12 h-12 rounded-2xl bg-white border border-emerald-100 text-emerald-400 flex items-center justify-center shrink-0 shadow-sm">
                    <i className="fab fa-twitter text-lg"></i>
                  </div>
                  <p className="text-stone-600 leading-relaxed font-medium text-sm pt-1">{post}</p>
                </div>
                <div className="absolute top-6 right-6 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button className="text-stone-300 hover:text-emerald-500 transition-colors">
                    <i className="fas fa-share-nodes text-lg"></i>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ContentGenerator;
