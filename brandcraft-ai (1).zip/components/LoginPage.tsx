
import React, { useState } from 'react';

interface LoginPageProps {
  onLogin: (username: string) => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [error, setError] = useState('');

  const validateUsername = (name: string) => {
    if (name.length < 3) {
      return "Username must be at least 3 characters long.";
    }
    const alphanumericRegex = /^[a-zA-Z0-9]+$/;
    if (!alphanumericRegex.test(name)) {
      return "Username must be alphanumeric (letters and numbers only).";
    }
    return "";
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validationError = validateUsername(username);
    if (validationError) {
      setError(validationError);
      return;
    }
    setError('');
    onLogin(username);
  };

  const doodles = [
    { icon: 'fa-signature', pos: 'top-10 left-[10%]', anim: 'animate-float' },
    { icon: 'fa-paint-brush', pos: 'top-20 right-[15%]', anim: 'animate-float-delayed' },
    { icon: 'fa-chart-line', pos: 'bottom-20 left-[12%]', anim: 'animate-float-slow' },
    { icon: 'fa-lightbulb', pos: 'bottom-40 right-[10%]', anim: 'animate-float' },
    { icon: 'fa-wand-magic-sparkles', pos: 'top-[40%] left-[5%]', anim: 'animate-float-delayed' },
    { icon: 'fa-bullhorn', pos: 'bottom-[10%] right-[30%]', anim: 'animate-float-slow' },
    { icon: 'fa-gem', pos: 'top-[60%] right-[5%]', anim: 'animate-float' },
  ];

  return (
    <div className="min-h-screen flex items-center justify-center bg-stone-50 px-4 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none select-none overflow-hidden">
        {doodles.map((doodle, idx) => (
          <div 
            key={idx} 
            className={`absolute ${doodle.pos} ${doodle.anim} text-rose-200 text-6xl opacity-40`}
          >
            <i className={`fas ${doodle.icon}`}></i>
          </div>
        ))}
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-rose-100/50 blur-3xl"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full bg-amber-100/30 blur-3xl"></div>
      </div>

      <div className="max-w-md w-full relative z-10">
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-28 h-28 rounded-[2.5rem] bg-indigo-950 p-6 shadow-2xl shadow-rose-200 mb-8 border-4 border-white/50">
            <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-[0_0_8px_rgba(255,255,255,0.3)]">
              <path d="M 50 10 L 90 50 L 50 90 L 10 50 Z" fill="none" stroke="#FFFFFF" strokeWidth="1" opacity="0.2" />
              <path d="M 32 30 V 70 H 45 C 55 70 58 60 58 52 C 58 46 54 42 48 42 C 54 42 56 36 56 32 C 56 26 52 22 42 22 H 32" fill="none" stroke="#FFFFFF" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M 72 32 C 68 22 55 20 48 24 C 40 28 38 45 42 58 C 45 68 55 78 68 76 C 75 75 78 68 78 60" fill="none" stroke="#FFFFFF" strokeWidth="7" strokeLinecap="round" opacity="0.85" />
            </svg>
          </div>
          <h1 
            className="text-5xl font-normal text-stone-900 mb-2 tracking-tight"
            style={{ fontFamily: "'Times New Roman', Times, serif" }}
          >
            Brand<span className="text-rose-600 italic">Craft</span>
          </h1>
          <p className="text-stone-500 font-medium text-lg">Your brand's evolution begins here.</p>
        </div>

        <div className="bg-white/80 backdrop-blur-xl p-10 rounded-[2.5rem] border border-stone-200 shadow-2xl shadow-stone-300/40">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="username" className="block text-sm font-bold text-stone-700 mb-2 ml-1">
                Corporate Username
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-rose-400">
                  <i className="fas fa-id-badge text-lg"></i>
                </div>
                <input
                  id="username"
                  type="text"
                  required
                  className={`w-full pl-12 pr-4 py-4 rounded-2xl border ${error ? 'border-rose-500 ring-rose-100' : 'border-stone-200 ring-rose-50'} focus:outline-none focus:ring-4 transition-all font-medium text-stone-900 placeholder-stone-400 text-lg`}
                  placeholder="e.g. creativeLead7"
                  value={username}
                  onChange={(e) => {
                    setUsername(e.target.value);
                    if (error) setError('');
                  }}
                />
              </div>
              {error && (
                <p className="mt-2 text-xs font-semibold text-rose-500 flex items-center gap-1.5 px-1 animate-pulse">
                  <i className="fas fa-exclamation-triangle"></i> {error}
                </p>
              )}
              
              <div className="mt-5 p-4 bg-stone-50 rounded-2xl border border-stone-100">
                <p className="text-[10px] text-stone-400 font-black uppercase tracking-[0.15em] mb-2.5">Security Policy</p>
                <div className="flex gap-4">
                  <div className={`flex items-center gap-1.5 text-[11px] font-bold ${username.length >= 3 ? 'text-rose-600' : 'text-stone-400'}`}>
                    <i className={`fas ${username.length >= 3 ? 'fa-check-circle' : 'fa-circle'}`}></i>
                    <span>LENGTH</span>
                  </div>
                  <div className={`flex items-center gap-1.5 text-[11px] font-bold ${/^[a-zA-Z0-9]+$/.test(username) && username.length > 0 ? 'text-rose-600' : 'text-stone-400'}`}>
                    <i className={`fas ${/^[a-zA-Z0-9]+$/.test(username) && username.length > 0 ? 'fa-check-circle' : 'fa-circle'}`}></i>
                    <span>ALPHANUMERIC</span>
                  </div>
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-rose-600 hover:bg-rose-700 text-white py-4 rounded-2xl font-black text-lg shadow-xl shadow-rose-600/30 transition-all active:scale-[0.98] hover:-translate-y-0.5 flex items-center justify-center gap-3 group"
            >
              Access Identity Suite
              <i className="fas fa-chevron-right text-sm group-hover:translate-x-1 transition-transform"></i>
            </button>
          </form>

          <div className="mt-10 pt-8 border-t border-stone-100 text-center">
            <p className="text-xs text-stone-400 font-bold tracking-widest uppercase">
              Authenticated Access Only
            </p>
          </div>
        </div>
        
        <div className="mt-12 text-center text-stone-400">
            <div className="flex justify-center gap-6 mb-4">
                <i className="fab fa-google text-lg hover:text-rose-400 cursor-pointer transition-colors"></i>
                <i className="fab fa-linkedin text-lg hover:text-rose-400 cursor-pointer transition-colors"></i>
                <i className="fab fa-github text-lg hover:text-rose-400 cursor-pointer transition-colors"></i>
            </div>
            <p className="text-[10px] font-bold uppercase tracking-[0.2em]">&copy; 2024 BrandCraft Automation Systems</p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
