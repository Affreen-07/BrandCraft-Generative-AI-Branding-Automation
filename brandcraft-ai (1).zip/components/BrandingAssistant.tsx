
import React, { useState, useEffect, useRef } from 'react';
import { getGeminiClient } from '../services/geminiService';

const BrandingAssistant: React.FC = () => {
  const [messages, setMessages] = useState<{ role: 'user' | 'model'; text: string }[]>([
    { role: 'model', text: 'Hi! I am your BrandCraft strategist. Need help with naming, positioning, or marketing advice?' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  
  const chatRef = useRef<any>(null);

  useEffect(() => {
    const ai = getGeminiClient();
    chatRef.current = ai.chats.create({
      model: 'gemini-3-flash-preview',
      config: {
        systemInstruction: "You are a world-class branding consultant and CMO. You help users with brand names, marketing strategies, logo feedback, and tone of voice. Keep answers concise, creative, and professional."
      }
    });
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;
    
    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const response = await chatRef.current.sendMessage({ message: userMsg });
      setMessages(prev => [...prev, { role: 'model', text: response.text }]);
    } catch (e) {
      setMessages(prev => [...prev, { role: 'model', text: "Sorry, I encountered an error. Please try again." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col flex-1 h-full bg-[#fafafa]">
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6">
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] px-5 py-3.5 rounded-2xl text-sm font-medium leading-relaxed shadow-sm ${
              msg.role === 'user' 
                ? 'bg-rose-100 text-rose-800 rounded-tr-none border border-rose-200' 
                : 'bg-white text-stone-700 border border-stone-100 rounded-tl-none'
            }`}>
              {msg.text}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-white border border-stone-100 rounded-2xl px-5 py-3 rounded-tl-none shadow-sm">
              <div className="flex gap-1.5">
                <div className="w-2 h-2 bg-rose-200 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-rose-200 rounded-full animate-bounce [animation-delay:-.3s]"></div>
                <div className="w-2 h-2 bg-rose-200 rounded-full animate-bounce [animation-delay:-.5s]"></div>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="p-6 border-t border-stone-100 bg-white">
        <div className="flex gap-3">
          <input
            type="text"
            className="flex-1 bg-stone-50 border border-stone-100 focus:ring-4 focus:ring-rose-50 rounded-2xl px-5 py-3.5 text-sm font-medium focus:outline-none"
            placeholder="Type your strategy query..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          />
          <button 
            onClick={handleSend}
            disabled={loading}
            className="w-12 h-12 bg-rose-100 text-rose-700 border border-rose-200 rounded-2xl flex items-center justify-center hover:bg-rose-200 disabled:opacity-50 transition-all shadow-sm"
          >
            <i className="fas fa-paper-plane"></i>
          </button>
        </div>
      </div>
    </div>
  );
};

export default BrandingAssistant;
