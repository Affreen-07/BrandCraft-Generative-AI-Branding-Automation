
import React from 'react';
import { BrandFeature } from '../types';

interface SidebarProps {
  activeTab: BrandFeature;
  setActiveTab: (tab: BrandFeature) => void;
  onLogout: () => void;
  username: string;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, onLogout, username }) => {
  const menuItems = [
    { id: BrandFeature.DASHBOARD, icon: 'fa-th-large', label: 'Overview', color: 'bg-rose-50 text-rose-500' },
    { id: BrandFeature.NAME_GEN, icon: 'fa-signature', label: 'Brand Naming', color: 'bg-sky-50 text-sky-500' },
    { id: BrandFeature.LOGO_GEN, icon: 'fa-paint-brush', label: 'Logo Studio', color: 'bg-amber-50 text-amber-500' },
    { id: BrandFeature.CONTENT_GEN, icon: 'fa-file-alt', label: 'Content Lab', color: 'bg-emerald-50 text-emerald-500' },
    { id: BrandFeature.SENTIMENT, icon: 'fa-chart-line', label: 'Sentiment AI', color: 'bg-purple-50 text-purple-500' },
  ];

  return (
    <aside className="w-72 bg-white border-r border-stone-100 flex flex-col shrink-0 transition-all duration-300">
      <div className="p-10">
        <div className="flex items-center gap-4 text-stone-800 mb-14">
          <div className="w-12 h-12 rounded-2xl bg-indigo-950 flex items-center justify-center shadow-sm border border-stone-200 p-2.5">
            <svg viewBox="0 0 100 100" className="w-full h-full">
              <path d="M 50 10 L 90 50 L 50 90 L 10 50 Z" fill="none" stroke="#FFFFFF" strokeWidth="1" opacity="0.3" />
              <path d="M 32 30 V 70 H 45 C 55 70 58 60 58 52 C 58 46 54 42 48 42 C 54 42 56 36 56 32 C 56 26 52 22 42 22 H 32" fill="none" stroke="#FFFFFF" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M 72 32 C 68 22 55 20 48 24 C 40 28 38 45 42 58 C 45 68 55 78 68 76 C 75 75 78 68 78 60" fill="none" stroke="#FFFFFF" strokeWidth="7" strokeLinecap="round" opacity="0.85" />
            </svg>
          </div>
          <div>
            <span 
              className="text-xl font-normal tracking-tight block"
              style={{ fontFamily: "'Times New Roman', Times, serif" }}
            >
              Brand<span className="italic text-rose-500">Craft</span>
            </span>
            <span className="text-[9px] uppercase tracking-[0.3em] font-bold text-stone-400">Automation</span>
          </div>
        </div>

        <nav className="space-y-3">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-4 px-5 py-4 rounded-[1.25rem] transition-all duration-300 group ${
                activeTab === item.id
                  ? `${item.color.split(' ')[0]} shadow-sm border border-stone-100`
                  : 'hover:bg-stone-50'
              }`}
            >
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
                activeTab === item.id ? item.color : 'bg-stone-50 text-stone-400'
              }`}>
                 <i className={`fas ${item.icon} text-sm`}></i>
              </div>
              <span className={`font-black text-sm tracking-tight ${
                activeTab === item.id ? 'text-stone-800' : 'text-stone-500 group-hover:text-stone-700'
              }`}>
                {item.label}
              </span>
            </button>
          ))}
        </nav>
      </div>

      <div className="mt-auto p-8 space-y-6">
        <div className="bg-stone-50/50 border border-stone-100 rounded-3xl p-6">
          <div className="flex items-center gap-4 mb-5">
            <div className="w-12 h-12 rounded-2xl bg-white border border-stone-100 flex items-center justify-center text-stone-300 text-lg overflow-hidden p-2.5">
              <svg viewBox="0 0 100 100" className="w-full h-full opacity-40">
                <path d="M 32 30 V 70 H 45 C 55 70 58 60 58 52 C 58 46 54 42 48 42 C 54 42 56 36 56 32 C 56 26 52 22 42 22 H 32" fill="none" stroke="currentColor" strokeWidth="12" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M 72 32 C 68 22 55 20 48 24 C 40 28 38 45 42 58 C 45 68 55 78 68 76 C 75 75 78 68 78 60" fill="none" stroke="currentColor" strokeWidth="10" strokeLinecap="round" opacity="0.85" />
              </svg>
            </div>
            <div className="truncate">
              <p className="text-xs font-black text-stone-800 truncate">{username}</p>
              <p className="text-[9px] text-stone-400 font-bold uppercase tracking-wider">Enterprise</p>
            </div>
          </div>
          <button 
            onClick={onLogout}
            className="w-full flex items-center justify-center gap-3 text-xs font-black text-rose-400 hover:text-rose-600 transition-colors bg-white py-3 rounded-2xl border border-rose-50 shadow-sm"
          >
            <i className="fas fa-power-off"></i>
            Sign Out
          </button>
        </div>

        <div className="text-center">
            <p className="text-[9px] text-stone-300 font-bold uppercase tracking-[0.2em]">&copy; 2024 System v4.0</p>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
